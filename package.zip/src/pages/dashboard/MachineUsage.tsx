import React from 'react';

const MachineUsage = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Machine Usage</h1>
      <p className="text-gray-600">Machine usage analytics functionality will be implemented here.</p>
    </div>
  );
};

export default MachineUsage;
