import React from 'react';

const ChallanHistory = () => {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold text-gray-900 mb-6">Challan History</h1>
      <p className="text-gray-600">Challan history functionality will be implemented here.</p>
    </div>
  );
};

export default ChallanHistory;
